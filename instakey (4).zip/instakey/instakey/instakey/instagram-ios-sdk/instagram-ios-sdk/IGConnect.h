//
//  IGConnect.h
//  instagram-ios-sdk
//
//  Created by Cristiano Severini on 18/04/12.
//  Copyright (c) 2012 IQUII. All rights reserved.
//

#import "Instagram.h"
#import "IGRequest.h"